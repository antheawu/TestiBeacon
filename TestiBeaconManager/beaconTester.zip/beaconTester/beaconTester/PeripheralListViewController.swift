//
//  PeripheralListViewController.swift
//  beaconTester
//
//  Created by 吳淑菁 on 2018/3/1.
//  Copyright © 2018年 吳淑菁. All rights reserved.
//

import UIKit
import CoreBluetooth
import ExternalAccessory

class PeripheralListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,CBCentralManagerDelegate  {
    
    
    
    @IBOutlet var deviceInfoList: UITableView?
    lazy private var cbManager : CBCentralManager = {
        let p = CBCentralManager.init(delegate: self, queue: nil)
        return p
    }()
    private var peripheralList: [CBPeripheral:Any] = [:]
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        cbManager.scanForPeripherals(withServices: nil, options: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        cbManager.stopScan()
        peripheralList.removeAll()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //  MARK:
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return peripheralList.keys.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell?
        let cellIdentifier = "tableCellTypeC"
        cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: cellIdentifier)
        }
        if indexPath.row < self.peripheralList.keys.count {
            let element = self.peripheralList[indexPath.row]
            let p = element.key
            if let n = p.name {
                cell?.textLabel?.text = n
            } else {
                cell?.textLabel?.text = "* Nameless Peripheral"
            }
            if let d = element.value as? Dictionary<String, Any> {
                cell?.detailTextLabel?.numberOfLines = 0
                cell?.detailTextLabel?.text = d.getStringDesc()
            }
        }
        
        return cell!
    }
    //  MARK:
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOff:
            print("poweredOff")
            break
        case .poweredOn:
            print("poweredOn")
            break
        case .unauthorized:
            print("unauthorized")
            break
        default:
            print("unknown")
            break
        }
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        if let _ = self.peripheralList[peripheral] {
            self.peripheralList[peripheral] = advertisementData
        } else {
            self.peripheralList[peripheral] = advertisementData
        }
        
        self.deviceInfoList?.reloadData()
    }
    

    
}

extension Dictionary {
    subscript(i:Int) -> (key:Key,value:Value) {
        get {
            return self[index(startIndex, offsetBy: i)];
        }
    }
    
    func getStringDesc() -> String {
        var s = ""
        
        for kkey in keys {
            if let key = kkey as? String {
                if key == "kCBAdvDataIsConnectable", let t =  self[kkey] as? Int {
                    s = s+"\(key): \(t)\n"
                } else if key == "kCBAdvDataManufacturerData" {
                    
                    if let data = self[kkey] as? Data, data.count > 25 {
                        let ud = data.subdata(in: 4..<20)
                        if let uuid = UUID(data: ud) {
                            s = s+"some UUID: \(uuid.uuidString) \n"
                            print("kCBAdvDataManufacturerData: \(uuid.uuidString)")
                        }
                        let M = data.subdata(in: 20..<22)
                        let m0: UInt16 = M.withUnsafeBytes { $0.pointee }
                        let major = (m0 >> 8) | (m0 << 8)
                        s = s+"major: \(major) \n"
                        
                        let m = data.subdata(in: 22..<24)
                        let m1: UInt16 = m.withUnsafeBytes { $0.pointee }
                        let minor = (m1 >> 8) | (m1 << 8)
                        s = s+"minor: \(minor) \n"
                        
                        let R = data.subdata(in: 24..<25)
                        let rssi: Int8 = R.withUnsafeBytes { $0.pointee }
                        s = s+"rssi: \(rssi) \n"
                    } else {
                        s = s+"\(key): \(self[kkey].debugDescription)\n"
                    }
                } else {
                    s = s+"\(key): \(self[kkey].debugDescription)\n"
                }
                
            }
        }
        
        return s
    }
    
}

extension UUID {
    
    public init?(data: Data) {
        
        guard data.count == 16 else { return nil }
        
        self.init(uuid: uuid_t(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15]))
    }
}
