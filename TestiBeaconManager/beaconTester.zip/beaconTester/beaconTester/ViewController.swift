//
//  ViewController.swift
//  beaconTester
//
//  Created by 吳淑菁 on 2018/2/26.
//  Copyright © 2018年 吳淑菁. All rights reserved.
//

import UIKit
import CoreBluetooth
import ExternalAccessory
import CoreLocation

let uuid = "FDA50693-A4E2-4FB1-AFCF-C6EB07647825"

class ViewController: UIViewController,CLLocationManagerDelegate, UITableViewDelegate, UITableViewDataSource {
    
    private var locationManager : CLLocationManager?

    @IBOutlet weak var tableview: UITableView?
    private var bState : CLRegionState = .unknown
    private var beacons : [CLBeacon] = []
    private var regions : [CLRegion] = []
    
    lazy var uuidfield : UITextField = {
        let w = (self.view.bounds.width-80)
        let p = UITextField(frame: CGRect(x: 80, y: 32+6, width: w-20, height: 20))
        p.font = UIFont.systemFont(ofSize: 12)
        p.text = uuid
        return p
    }()

    
    lazy private var uuidHeader : UIView = {
        let f = UIView(frame: CGRect(x:0,y:0,width:self.view.bounds.width,height:64.0))
        let t1 = UILabel(frame:CGRect(x: 10, y: 0, width: 200,height: 32))
        t1.text = "Beacon Monitoring..."
        f.addSubview(t1)
        //f.backgroundColor = UIColor.white
        let l3 = UILabel(frame:CGRect(x: 10, y: 32, width: 60,height: 32))
        l3.text = "UUID:"
        l3.font = UIFont.boldSystemFont(ofSize: 12)
        l3.textColor = UIColor.black
        f.addSubview(self.uuidfield)
        f.addSubview(l3)
        
        return f
    }()
    
    lazy private var uuidHeader2 : UIView = {
        let f = UIView(frame: CGRect(x:0,y:0,width:self.view.bounds.width,height:32.0))
        let t1 = UILabel(frame:CGRect(x: 10, y: 0, width: 200,height: 32))
        t1.text = "Beacon Ranging..."
        f.addSubview(t1)
        
        return f
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.locationManager = CLLocationManager()
        self.locationManager?.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // MARK: -
    func stopRanging(_ sender:Any?) {
        if let first = self.regions.first as? CLBeaconRegion{
            self.locationManager?.stopRangingBeacons(in: first)
        }
    }
    func rangingBeacons(_ sender: Any?) {
        if let s = sender as? UISwitch, !s.isOn {
            stopRanging(s)
            return
        }

        if CLLocationManager.authorizationStatus() == .notDetermined {
            //self.locationManager?.requestAlwaysAuthorization()
            self.locationManager?.requestWhenInUseAuthorization()
            return
        }
        

        if CLLocationManager.isRangingAvailable() {
            let proximityUUID = UUID(uuidString:uuid)
            let beaconID = "BC02"
            
            // Create the region and begin monitoring it.
            let region = CLBeaconRegion(proximityUUID: proximityUUID!,
                                        identifier: beaconID)
            region.notifyEntryStateOnDisplay = true
            region.notifyOnEntry = true
            region.notifyOnExit = true
            
            self.locationManager?.startRangingBeacons(in: region)
        }
    }
    func stopMonitor(_ sender: Any?) {
        if let first = self.regions.first {
            self.locationManager?.stopMonitoring(for: first)
        }
    }
    func monitorBeacons(_ sender: Any?) {
        if let s = sender as? UISwitch, !s.isOn {
            stopMonitor(s)
            return
        }
        
        if CLLocationManager.authorizationStatus() == .notDetermined {
            self.locationManager?.requestAlwaysAuthorization()
            //self.locationManager?.requestWhenInUseAuthorization()
            return
        }
        
        if CLLocationManager.isMonitoringAvailable(for:
            CLBeaconRegion.self) {
            if bState == .unknown {
                // Match all beacons with the specified UUID
                let proximityUUID = UUID(uuidString:uuid)
                let beaconID = "BC02"
                
                // Create the region and begin monitoring it.
                let region = CLBeaconRegion(proximityUUID: proximityUUID!,
                                            identifier: beaconID)
                region.notifyEntryStateOnDisplay = true
                region.notifyOnEntry = true
                region.notifyOnExit = true
                self.locationManager?.desiredAccuracy = kCLLocationAccuracyBest
                self.locationManager?.startMonitoring(for: region)
            } else {
                
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didDetermineState state: CLRegionState, for region: CLRegion) {
        if let _ = region as? CLBeaconRegion {
            self.bState = state
            switch state {
            case .inside:
                //manager.startRangingBeacons(in: region)//startMonitoring(for: region)//startRangingBeaconsInRegion(region)
                self.appendRegion(region as? CLBeaconRegion)
                print("inside")
            case .outside:
                // Let it do ranging for a sec to update currentRegions
                //delay(1.0) {
                //    manager.stopRangingBeacons(in: region)
                    //manager.stopMonitoring(for: region)
                //}
                print("outside")
                break
            case .unknown:
                print("unknown")
                break
            }
            
        }
    }
    
    private func delay(_ delay:Double, closure: @escaping ()->()) {
        
        DispatchQueue.main.asyncAfter(deadline: .now()+delay) {
            closure()
        }
        
    }
    func locationManager(_ manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], in region: CLBeaconRegion){
        if beacons.count > 0 {
            let nearestBeacon = beacons.first!
            appendBeacon(nearestBeacon)
        }
    }
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion){
        if region is CLBeaconRegion {
            // Start ranging only if the feature is available.
            if CLLocationManager.isRangingAvailable() {
                //manager.startRangingBeacons(in: region as! CLBeaconRegion)
                self.appendRegion(region as? CLBeaconRegion)
                // Store the beacon so that ranging can be stopped on demand.
                //beaconsToRange.append(region as! CLBeaconRegion)
            }
        }
    }
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        if let r = region as? CLBeaconRegion, let i = self.regions.index(of: r) {
            self.regions.remove(at: i)
            let ss = IndexSet(arrayLiteral:0)
            self.tableview?.reloadSections(ss, with: .automatic)
        }
    }
    func locationManager(_ manager: CLLocationManager, monitoringDidFailFor region: CLRegion?, withError error: Error) {
        print(error)
    }
    func locationManager(_ manager: CLLocationManager, rangingBeaconsDidFailFor region: CLBeaconRegion, withError error: Error) {
        
        print(error)
    }
 
    private func appendRegion(_ region: CLBeaconRegion?) {
        if let r = region {
            if !self.regions.contains(r) {
                self.regions.append(r)
                let ss = IndexSet(arrayLiteral:0)
                self.tableview?.reloadSections(ss, with: .automatic)
            }
        }
    }
    private func appendBeacon(_ beacon: CLBeacon?) {
        if let b = beacon {
            let target = self.beacons.filter({ (b0) -> Bool in
                if b0.proximityUUID.uuidString == b.proximityUUID.uuidString,
                    b0.major == b.major,b0.minor == b.minor {
                    return true
                }
                
                return false
            })
            if target.count > 0 {
                for t in target {
                    if let it = self.beacons.index(of: t) {
                        self.beacons.remove(at: it)
                    }
                }
            }
            
            self.beacons.append(b)
            
            let ss = IndexSet(arrayLiteral:1)
            self.tableview?.reloadSections(ss, with: .automatic)
        }
    }
    //  MARK: -
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 64
        }
        
        return 32
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Beacon Monitoring..."
        }
        return "Beacon Ranging..."
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 {
            return self.uuidHeader
        }
        
        return uuidHeader2//UIView(frame:CGRect(x: 0, y: 0, width: self.view.bounds.width, height: 4))
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 48
        }
        
        return 64
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return self.regions.count+1
        default:
            return self.beacons.count+1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell?
        
        if indexPath.row == 0 {
            let cellIdentifier = "tableCellTypeA"//NATSectionType(rawValue: (indexPath as NSIndexPath).section)?.cellIdentifier()
            cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
            if cell == nil {
                cell = UITableViewCell(style: .subtitle, reuseIdentifier: cellIdentifier)
            }
            switch indexPath.section {
            case 0 :
                if let u = cell?.contentView.viewWithTag(1110) {
                    u.removeFromSuperview()
                }

                if let b = cell?.contentView.viewWithTag(1111) as? UISwitch {
                    b.isOn = (self.regions.count > 0)
                } else {
                    let s = UISwitch(frame: CGRect(x: 20, y: 10, width: 64, height: 48))
                    s.isOn = (self.regions.count > 0)
                    s.addTarget(self, action: #selector(monitorBeacons), for: .valueChanged)
                    s.tag = 1111
                    cell?.contentView.addSubview(s)

                }
                break
            case 1:
                if let u = cell?.contentView.viewWithTag(1111) {
                    u.removeFromSuperview()
                }
                if let b = cell?.contentView.viewWithTag(1110) as? UISwitch {
                    b.isOn = (self.beacons.count > 0)
                } else {
                    let s = UISwitch(frame: CGRect(x: 20, y: 10, width: 64, height: 48))
                    s.isOn = (self.beacons.count > 0)
                    s.addTarget(self, action: #selector(rangingBeacons), for: .valueChanged)
                    s.tag = 1110
                    cell?.contentView.addSubview(s)
                    /*
                    let btn = UIButton(type: .system)
                    btn.frame = CGRect(x:20 , y:0 , width: 120, height: 48)
                    if self.beacons.count > 0 {
                        btn.setTitle("Stop Ranging", for: .normal)
                        btn.addTarget(self, action: #selector(stopRanging), for: .touchUpInside)
                    } else {
                        btn.setTitle("Start Ranging", for: .normal)
                        btn.addTarget(self, action: #selector(rangingBeacons), for: .touchUpInside)
                    }
                    btn.contentHorizontalAlignment = .left
                    btn.tag = 1110
 
                    cell?.contentView.addSubview(btn)
                    */
                }
                break
            default:
                break
            }
        } else {
            let cellIdentifier = "tableCellTypeB"//NATSectionType(rawValue: (indexPath as NSIndexPath).section)?.cellIdentifier()
            cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
            if cell == nil {
                cell = UITableViewCell(style: .subtitle, reuseIdentifier: cellIdentifier)
            }
            switch indexPath.section {
            case 0 :
                if indexPath.row-1 < self.regions.count,
                    let region = self.regions[indexPath.row-1] as? CLBeaconRegion {                                    
                    cell?.textLabel?.font = UIFont.systemFont(ofSize: 12)
                    cell?.textLabel?.text = region.proximityUUID.uuidString
                    cell?.detailTextLabel?.text = ""
                    if let M = region.major, let m = region.minor {
                        cell?.detailTextLabel?.text = "major:\(M) minor:\(m)"
                    }
                    
                }
                
                break
            case 1:
                if indexPath.row-1 < self.beacons.count {
                    let beacon = self.beacons[indexPath.row-1]
                    cell?.textLabel?.font = UIFont.systemFont(ofSize: 12)
                    cell?.textLabel?.text = beacon.proximityUUID.uuidString
                    cell?.detailTextLabel?.font = UIFont.systemFont(ofSize: 12)
                    cell?.detailTextLabel?.numberOfLines = 0
                    cell?.detailTextLabel?.textColor = UIColor.blue
                    cell?.detailTextLabel?.text = "\(beacon.detail())"
                    
                }
                break
            default:
                break
            }
        }
        if let cc = cell {
            cc.selectionStyle = .none
        }
        return cell!
    }
    
}
// MARK: -
extension CLBeacon {
    
    func getProximity() -> String{
        switch self.proximity {
        case .far :
            return "far"
        case .immediate :
            return "immediate"
        case .near:
            return "near"
        default:
            return "unknown"
        }
    }
    func detail() -> String {
        return "major:\(major), minor:\(minor) \n\(getProximity()):\(accuracy) \nRSSI:\(rssi)"
    }
}
