//
//  AppDelegate.swift
//  beaconTester
//
//  Created by 吳淑菁 on 2018/2/26.
//  Copyright © 2018年 吳淑菁. All rights reserved.
//

import UIKit
import CoreBluetooth
import CoreLocation
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,CLLocationManagerDelegate,UNUserNotificationCenterDelegate {

    var window: UIWindow?
    private var locationManager : CLLocationManager = CLLocationManager()
    private var regions : [CLRegion] = []

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        self.locationManager.delegate = self
        self.monitorBeacons(nil)
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    //  MARK: - entry point for monitoring beacon regions...
    private func monitorBeacons(_ sender: Any?) {
        
        //  get Notification grant
        let options: UNAuthorizationOptions = [.alert,.sound]
        UNUserNotificationCenter.current().requestAuthorization(options: options) {
            (granted, error) in
            if !granted {
                debugPrint("Something went wrong")
            } else {
                debugPrint("Notifications granted")
                
            }
        }
        
        //  get location authrization
        if CLLocationManager.authorizationStatus() == .notDetermined {
            self.locationManager.requestAlwaysAuthorization()
            //self.locationManager?.requestWhenInUseAuthorization()
            return
        }
        
        //  check if CLLocationManager is capable of beacon monitoring
        if CLLocationManager.isMonitoringAvailable(for:
            CLBeaconRegion.self) {
            
            //  known proximity UUID
            let proximityUUID = UUID(uuidString:uuid)
            let beaconID = "BC02"
            
            
            // Create the region and begin monitoring it.
            let region = CLBeaconRegion(proximityUUID: proximityUUID!,
                                        identifier: beaconID)
            //region.notifyEntryStateOnDisplay = true
            region.notifyOnEntry = true
            region.notifyOnExit = false
            self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
            
            
            //  generate local notification for triggering app when not foreground
            let content = UNMutableNotificationContent()
            content.title = "Wellcome!"
            content.body = "Swipe or tap this message to see what's new!"
            //  repeat is annoying...
            let trigger = UNLocationNotificationTrigger(region: region, repeats: false)
            let request = UNNotificationRequest.init(identifier: "BeaconNotificationIdentifier", content: content, trigger: trigger)
            
            UNUserNotificationCenter.current().removeAllPendingNotificationRequests()

            UNUserNotificationCenter.current().delegate = self
            UNUserNotificationCenter.current().add(request, withCompletionHandler: { (error) in
                
            })
            
            //  start monitoring the beacon region
            self.locationManager.startMonitoring(for: region)
            
            
            
        }
    }
    private func appendRegion(_ region: CLBeaconRegion?) {
        if let r = region {
            if !self.regions.contains(r) {
                self.regions.append(r)
                
            }
        }
    }
    
    // MARK: - CLLocationManager Delegate function
    //  entering a region
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion){
        if region is CLBeaconRegion {
            // Start ranging only if the feature is available.
            if CLLocationManager.isRangingAvailable() {
                //  store the region
                self.appendRegion(region as? CLBeaconRegion)
                
                
            }
        }
    }
    //  exiting a region
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        if let r = region as? CLBeaconRegion, let i = self.regions.index(of: r) {
            self.regions.remove(at: i)
            //let ss = IndexSet(arrayLiteral:0)
            //self.tableview?.reloadSections(ss, with: .automatic)
        }
    }
    //  monitoring failed
    func locationManager(_ manager: CLLocationManager, monitoringDidFailFor region: CLRegion?, withError error: Error) {
        print(error)
    }
    
    // MARK: UserNotificationCenter delegate funtions
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Swift.Void) {
        if let trigger = notification.request.trigger as? UNLocationNotificationTrigger,
            let region = trigger.region as? CLBeaconRegion {
            print(region)
        }
        
        completionHandler([.alert, .sound])
    }
    

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Swift.Void) {
        completionHandler()
    }
}

